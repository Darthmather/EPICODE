CREATE DATABASE IF NOT EXISTS vendicose;
USE vendicose;

CREATE TABLE category (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  category_name        VARCHAR(100) NOT NULL UNIQUE,
  category_description VARCHAR(255) NULL
);

CREATE TABLE product (
  product_id  INT AUTO_INCREMENT PRIMARY KEY,
  product_name        VARCHAR(150) NOT NULL,
  price  DECIMAL(10,2) NOT NULL,
  category_id INT NOT NULL,
  CONSTRAINT fk_product_category
    FOREIGN KEY (category_id) REFERENCES category(category_id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE warehouse (
  ws_id INT AUTO_INCREMENT PRIMARY KEY,
  ws_name         VARCHAR(120) NOT NULL,
  address      VARCHAR(255) NOT NULL
);

CREATE TABLE store (
  store_id     INT AUTO_INCREMENT PRIMARY KEY,
  store_name         VARCHAR(120) NOT NULL,
  address      VARCHAR(255) NOT NULL,
  ws_id INT NOT NULL,
  CONSTRAINT fk_store_warehouse
    FOREIGN KEY (ws_id) REFERENCES warehouse(ws_id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE warehouse_stock (
  ws_id INT NOT NULL,
  product_id   INT NOT NULL,
  stock_quantity  INT NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
               ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (ws_id, product_id),
  CONSTRAINT fk_ws_warehouse
    FOREIGN KEY (ws_id) REFERENCES warehouse(ws_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_ws_product
    FOREIGN KEY (product_id) REFERENCES product(product_id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE sale (
  sale_id INT AUTO_INCREMENT PRIMARY KEY,
  store_id INT NOT NULL,
  sold_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sale_store
    FOREIGN KEY (store_id) REFERENCES store(store_id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE sale_line (
  sale_id    INT NOT NULL,
  line_no    INT,
  product_id INT NOT NULL,
  quantity        INT NOT NULL CHECK (quantity > 0),
  PRIMARY KEY (sale_id, line_no),
  CONSTRAINT fk_sl_sale
    FOREIGN KEY (sale_id) REFERENCES sale(sale_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_sl_product
    FOREIGN KEY (product_id) REFERENCES product(product_id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Popolamento completo in una singola query
INSERT INTO warehouse (ws_id, ws_name, address) VALUES
(1, 'Central Depot', 'Via Roma 100, Milano'),
(2, 'South Hub', 'Via Napoli 45, Napoli'),
(3, 'North Hub', 'Via Torino 12, Torino');

INSERT INTO store (store_id, store_name, address, ws_id) VALUES
(1, 'Store Milano', 'Corso Buenos Aires 10, Milano', 1),
(2, 'Store Napoli', 'Via Toledo 22, Napoli', 2),
(3, 'Store Torino', 'Via Garibaldi 5, Torino', 3),
(4, 'Store Firenze', 'Via dei Calzaiuoli 8, Firenze', 1),
(5, 'Store Bologna', 'Via Indipendenza 20, Bologna', 2),
(6, 'Store Genova', 'Via XX Settembre 15, Genova', 3);

INSERT INTO category (category_id, category_name, category_description) VALUES
(1, 'Electronics', 'Devices and gadgets'),
(2, 'Toys', 'Children and educational toys'),
(3, 'Sports', 'Outdoor and fitness equipment'),
(4, 'Books', 'Fiction and educational books'),
(5, 'Home', 'Household essentials');

INSERT INTO product (product_id, product_name, price, category_id) VALUES
(1, 'Smartphone X', 699.99, 1),
(2, 'Tablet Z', 499.99, 1),
(3, 'Building Blocks', 29.99, 2),
(4, 'RC Car', 59.99, 2),
(5, 'Yoga Mat', 19.99, 3),
(6, 'Tennis Racket', 89.99, 3),
(7, 'Novel A', 14.99, 4),
(8, 'Science Book', 24.99, 4),
(9, 'Vacuum Cleaner', 129.99, 5),
(10, 'Blender', 49.99, 5),
(11, 'Puzzle 1000 pcs', 19.99, 2),
(12, 'Football', 25.99, 3),
(13, 'Smartwatch', 199.99, 1),
(14, 'Cookbook', 18.99, 4),
(15, 'Iron', 39.99, 5);

INSERT INTO warehouse_stock (ws_id, product_id, stock_quantity, updated_at) VALUES
(1, 1, 40, '2026-01-10 10:00:00'),
(1, 2, 25, '2026-01-10 10:00:00'),
(1, 3, 80, '2026-01-10 10:00:00'),
(1, 4, 60, '2026-01-10 10:00:00'),
(2, 5, 100, '2026-01-10 11:00:00'),
(2, 6, 50, '2026-01-10 11:00:00'),
(2, 7, 70, '2026-01-10 11:00:00'),
(2, 8, 40, '2026-01-10 11:00:00'),
(3, 9, 30, '2026-01-10 12:00:00'),
(3, 10, 45, '2026-01-10 12:00:00'),
(3, 11, 90, '2026-01-10 12:00:00'),
(3, 12, 55, '2026-01-10 12:00:00'),
(1, 13, 35, '2026-01-10 10:00:00'),
(2, 14, 60, '2026-01-10 11:00:00'),
(3, 15, 50, '2026-01-10 12:00:00');