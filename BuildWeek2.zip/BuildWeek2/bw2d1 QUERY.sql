/*
* per gestire l'inserimento di una nuova vendita nel database, più tabelle vengono aggiornate
* in sale andiamo ad inserire lo store che ha effettuato la vendita, e il timestamp della transazione con NOW()
* in sale_line il dettaglio dello scontrino
* infine l'aggiornamento dello stock in magazzino
*/

/*
* in questo esempio abbiamo venduto, nella stessa transazione, 3 prodotti con le rispettive quantità 
* utilizzo la funzionalità di definizione delle variabili tramite SET
*/

SET @qty_product1 = 5;
SET @qty_product2 = 10;
SET @qty_product3 = 25;

SET @storeid = 1;

SET @stock_product1 = (SELECT stock_quantity FROM warehouse_stock ws
                       JOIN store s ON s.ws_id = ws.ws_id
                       WHERE s.store_id = @storeid AND ws.product_id = 1);
                       
SET @stock_product2 = (SELECT stock_quantity FROM warehouse_stock ws
                       JOIN store s ON s.ws_id = ws.ws_id
                       WHERE s.store_id = @storeid AND ws.product_id = 2);
                       
SET @stock_product3 = (SELECT stock_quantity FROM warehouse_stock ws
                       JOIN store s ON s.ws_id = ws.ws_id
                       WHERE s.store_id = @storeid AND ws.product_id = 3);

START TRANSACTION;
IF (@stock_product1 < @qty_product1 OR @stock_product2 < @qty_product2 OR @stock_product3 < @qty_product3) 
	ROLLBACK;
ELSE

INSERT INTO sale (store_id, sold_at)
VALUES (@storeid, NOW());
-- Recupera l'ID della vendita
SET @sale_id = LAST_INSERT_ID();

-- linee dello scontrino
INSERT INTO sale_line (sale_id, line_no, product_id, quantity) VALUES
	(@sale_id, 1, 1, @qty_product1), 
    (@sale_id, 2, 2, @qty_product2),
    (@sale_id, 3, 3, @qty_product3);

UPDATE warehouse_stock ws
JOIN store s ON s.ws_id = ws.ws_id
JOIN sale_line sl ON sl.product_id = ws.product_id
SET ws.stock_quantity = ws.stock_quantity - @qty_product1
WHERE s.store_id = @storeid AND ws.product_id = 1;

UPDATE warehouse_stock ws
JOIN store s ON s.ws_id = ws.ws_id
JOIN sale_line sl ON sl.product_id = ws.product_id
SET ws.stock_quantity = ws.stock_quantity - @qty_product2
WHERE s.store_id = @storeid AND ws.product_id = 2;

UPDATE warehouse_stock ws
JOIN store s ON s.ws_id = ws.ws_id
JOIN sale_line sl ON sl.product_id = ws.product_id
SET ws.stock_quantity = ws.stock_quantity - @qty_product3
WHERE s.store_id = @storeid AND ws.product_id = 3;