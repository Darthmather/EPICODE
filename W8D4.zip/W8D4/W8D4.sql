-- Creazione e selezione dello schema progettato
CREATE SCHEMA toysgroup;
USE toysgroup;

-- Creazione tabella Category (gerarchia per Product)
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY AUTO_INCREMENT,
    CategoryName VARCHAR(100) NOT NULL
);

-- Creazione tabella Product
CREATE TABLE Product (
    ProductID INT PRIMARY KEY AUTO_INCREMENT,
    ProductName VARCHAR(100) NOT NULL,
    Price DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

-- Creazione tabella Region (gerarchia per Country)
CREATE TABLE Region (
    RegionID INT PRIMARY KEY AUTO_INCREMENT,
    RegionName VARCHAR(100) NOT NULL
);

-- Creazione tabella Country
CREATE TABLE Country (
    CountryID INT PRIMARY KEY AUTO_INCREMENT,
    CountryName VARCHAR(100) NOT NULL,
    RegionID INT,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Creazione tabella Sales
CREATE TABLE Sales (
    SalesID INT PRIMARY KEY AUTO_INCREMENT,
    SalesDate DATE NOT NULL,
    Quantity INT NOT NULL,
    ProductID INT,
    CountryID INT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (CountryID) REFERENCES Country(CountryID)
);

-- Popolamento tabella Category
INSERT INTO Category (CategoryName) VALUES
('Action Figures'), ('Board Games'), ('Educational'), ('Outdoor'), ('Electronic');

-- Popolamento tabella Product
INSERT INTO Product (ProductName, Price, CategoryID) VALUES
('Superhero Figure', 15.99, 1), ('Dragon Figure', 12.50, 1), ('Chess Set', 25.00, 2), ('Monopoly', 30.00, 2), ('Math Puzzle', 10.00, 3),
('Science Kit', 18.75, 3), ('Football', 20.00, 4), ('Jump Rope', 5.50, 4), ('RC Car', 45.00, 5), ('Drone', 120.00, 5);
-- Questi prodotti NON verranno venduti
INSERT INTO Product (ProductName, Price, CategoryID) VALUES
('Moon Base', 15.99, 2), ('Boy of the Moon Figure', 55.95, 1);

-- Popolamento tabella Region
INSERT INTO Region (RegionName) VALUES
('Europe'), ('North America'), ('Asia');

-- Popolamento tabella Country
INSERT INTO Country (CountryName, RegionID) VALUES
('Italy', 1), ('France', 1), ('Germany', 1), ('USA', 2), ('Canada', 2), ('Japan', 3), ('China', 3);

-- Popolamento tabella Sales
INSERT INTO Sales (SalesDate, Quantity, ProductID, CountryID) VALUES
('2025-01-10', 5, 1, 1),   -- 5 Superhero Figure venduti in Italy
('2025-01-12', 3, 2, 2),   -- 3 Dragon Figure venduti in France
('2025-01-15', 10, 3, 3),  -- 10 Chess Set venduti in Germany
('2025-01-20', 7, 4, 4),   -- 7 Monopoly venduti in USA
('2025-01-22', 4, 5, 5),   -- 4 Math Puzzle venduti in Canada
('2025-01-25', 6, 6, 6),   -- 6 Science Kit venduti in Japan
('2025-01-28', 8, 7, 7),   -- 8 Football venduti in China
('2025-02-01', 12, 8, 1),  -- 12 Jump Rope venduti in Italy
('2025-02-05', 2, 9, 4),   -- 2 RC Car venduti in USA
('2025-02-07', 1, 10, 6),  -- 1 Drone venduto in Japan
('2025-10-10', 5, 10, 1),   -- 5 Droni venduti in Italy
('2025-10-12', 3, 9, 2),   -- 3 RC Car venduti in France
('2025-11-15', 10, 8, 3),  -- 10 Jump Rope venduti in Germany
('2025-11-20', 7, 7, 4),   -- 7 Football venduti in USA
('2025-11-22', 4, 6, 5),   -- 4 Science Kit venduti in Canada
('2025-11-25', 6, 5, 6),   -- 6 Math Puzzle venduti in Japan
('2025-11-28', 8, 4, 7),   -- 8 Monopoly venduti in China
('2025-12-01', 12, 3, 1),  -- 12 Chess Set venduti in Italy
('2025-12-05', 2, 2, 4),   -- 2 Dragon Figure venduti in USA
('2025-12-07', 1, 1, 6),  -- 1 Superhero Figure in Japan
-- prodotti venduti nel 2024
('2024-01-10', 5, 1, 1),   -- 5 Superhero Figure venduti in Italy
('2024-01-12', 3, 2, 2),   -- 3 Dragon Figure venduti in France
('2024-01-15', 10, 3, 3);  -- 10 Chess Set venduti in Germany


/* Req#1
 * la query (eseguita sulle singole tabelle) restituisce nessun risultato, significa che la PK è rispettata
 */
SELECT CategoryID, COUNT(*) AS Occorrenze
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SELECT ProductID, COUNT(*) AS Occorrenze
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT RegionID, COUNT(*) AS Occorrenze
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SELECT CountryID, COUNT(*) AS Occorrenze
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

SELECT SalesID, COUNT(*) AS Occorrenze
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

/* Req#2
 * per definire il campo booleano viene utilizzata la funzione DATEDIFF -in associazione con CURDATE- 
 * per trovare i prodotti venduti oltre 180 giorni
 */
SELECT 
    s.SalesID,
    s.SalesDate,
    p.ProductName,
    c.CategoryName,
    co.CountryName,
    r.RegionName,
    CASE 
        WHEN DATEDIFF(CURDATE(), s.SalesDate) > 180 THEN TRUE
        ELSE FALSE
    END AS Oltre180Giorni
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
JOIN Country co ON s.CountryID = co.CountryID
JOIN Region r ON co.RegionID = r.RegionID
ORDER BY s.SalesDate;

/* Req#3
 * con HAVING SUM(s.Quantity) > SubQuery andiamo a filtrare solo i prodotti che hanno venduto più della media
 * media calcolata tramite AVG() sulle vendite per prodotto nell’ultimo anno
 */
SELECT 
    s.ProductID,
    SUM(s.Quantity) AS TotaleVenduto
FROM Sales s
WHERE YEAR(s.SalesDate) = (
    SELECT MAX(YEAR(SalesDate)) 
    FROM Sales
)
GROUP BY s.ProductID
HAVING SUM(s.Quantity) > ( -- filtriamo i prodotti la cui quantità venduta è superiore al valore della subquery
    SELECT AVG(TotalePerProdotto) -- qui calcoliamo la media delle quantità vendute
    FROM (
        SELECT SUM(s2.Quantity) AS TotalePerProdotto -- ricaviamo la quantità venduta per ogni prodotto
        FROM Sales s2
        WHERE YEAR(s2.SalesDate) = (
            SELECT MAX(YEAR(SalesDate)) 
            FROM Sales
        )
        GROUP BY s2.ProductID
    ) AS SubQuery -- alias necessario per conformità al linguaggio
);

/* Req#4
 */
SELECT 
    p.ProductID,
    p.ProductName,
    YEAR(s.SalesDate) AS Anno,
    SUM(p.Price*s.Quantity) AS FatturatoTotale
FROM Sales s
INNER JOIN Product p ON s.ProductID = p.ProductID -- tramite inner join escludiamo i prodotti non venduti
GROUP BY p.ProductID, YEAR(s.SalesDate) -- 
ORDER BY Anno;

/* Req#5
 */
SELECT 
    YEAR(s.SalesDate) AS Anno,
    co.CountryName AS Stato,
    SUM(p.Price*s.Quantity) AS FatturatoTotale
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Country co ON s.CountryID = co.CountryID
GROUP BY co.CountryName, YEAR(s.SalesDate) -- raggruppamento per Stato e per Anno
ORDER BY Anno DESC, FatturatoTotale DESC;

/* Req#6
 */
SELECT 
    c.CategoryName,
    SUM(s.Quantity) AS TotaleQuantità
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
GROUP BY c.CategoryName -- raggruppiamo i risultati per categoria
ORDER BY TotaleQuantità DESC
LIMIT 1; -- tramite questa istruzione restituiamo solo la categoria che è stata più richiesta dal mercato

/*Req#7
 * 1o approccio > tutti i prodotti il cui ProductID non compare nella tabella Sales.
 */
SELECT p.ProductID, p.ProductName
FROM Product p
WHERE p.ProductID NOT IN (
    SELECT DISTINCT s.ProductID
    FROM Sales s
);

/* 2o approccio > LEFT JOIN tra Product e Sales
 */
SELECT p.ProductID, p.ProductName
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.ProductID IS NULL;

/* Req#8
 */
CREATE VIEW ProdottiDenormalizzati AS
SELECT 
    p.ProductID AS CodiceProdotto,
    p.ProductName AS NomeProdotto,
    c.CategoryName AS NomeCategoria
FROM Product p
JOIN Category c ON p.CategoryID = c.CategoryID;

/* Req#9
 */
CREATE VIEW InfoGeografiche AS
SELECT 
    co.CountryID AS CodiceStato,
    co.CountryName AS NomeStato,
    r.RegionID AS CodiceRegione,
    r.RegionName AS NomeRegione
FROM Country co
JOIN Region r ON co.RegionID = r.RegionID;